"""Piper arm control utilities (no ROS)."""

