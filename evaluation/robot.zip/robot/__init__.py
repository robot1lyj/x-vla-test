"""ROS-free runner for SoftFold-Agilex (cameras + Piper)."""

