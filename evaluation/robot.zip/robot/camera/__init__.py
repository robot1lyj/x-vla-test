"""Lightweight camera utilities (OpenCV-based, no ROS)."""

